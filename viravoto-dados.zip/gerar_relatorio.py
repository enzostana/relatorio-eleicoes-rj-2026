from pathlib import Path
import json,csv,collections,html,math,base64,datetime,zipfile
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Polygon,Patch
from matplotlib.backends.backend_pdf import PdfPages
from openpyxl import Workbook,load_workbook
from openpyxl.styles import Font,PatternFill,Alignment
from openpyxl.utils import get_column_letter
import markdown
ROOT=Path(__file__).parent
rows=json.loads((ROOT/'resultados.json').read_text())
ibge={str(m['id']):m for m in json.loads((ROOT/'fontes/ibge_municipios.json').read_text())}
for r in rows:
 m=ibge[r['codigo_ibge']];r['municipio']=m['nome'];r['regiao_imediata']=m['regiao-imediata']['nome'];r['regiao_intermediaria']=m['regiao-imediata']['regiao-intermediaria']['nome']
rows.sort(key=lambda r:r['municipio'])
focus=[r for r in rows if r['douglas_lula']];lula=[r for r in rows if r['lider_presidente']=='LULA'];pin=focus[0]
assert len(rows)==92 and len(focus)==1 and pin['municipio']=='Pinheiral'
byid={r['codigo_ibge']:r for r in rows}
def n(x):return f'{x:,}'.replace(',','.')
def p(x):return f'{x:.2f}'.replace('.',',')
def group(r):return ('Ruas' if r['lider_governador']=='DOUGLAS RUAS' else 'Paes')+' + '+('Lula' if r['lider_presidente']=='LULA' else 'Flávio')
colors={'Ruas + Flávio':'#2563a6','Paes + Lula':'#b64c65','Paes + Flávio':'#aaa6bd','Ruas + Lula':'#dd841c'}
matrix=collections.Counter(group(r) for r in rows)
regional=[]
for region in sorted(set(r['regiao_intermediaria'] for r in rows)):
 rs=[r for r in rows if r['regiao_intermediaria']==region];gv=sum(r['governador_base_percentual'] for r in rs);pv=sum(r['presidente_base_percentual'] for r in rs)
 regional.append({'regiao':region,'municipios':len(rs),'ruas_lidera':sum(r['lider_governador']=='DOUGLAS RUAS' for r in rs),'paes_lidera':sum(r['lider_governador']=='EDUARDO PAES' for r in rs),'lula_lidera':sum(r['lider_presidente']=='LULA' for r in rs),'ruas_lula':sum(r['douglas_lula'] for r in rs),'douglas_pct':100*sum(r['douglas_votos'] for r in rs)/gv,'paes_pct':100*sum(r['paes_votos'] for r in rs)/gv,'lula_pct':100*sum(r['lula_votos'] for r in rs)/pv})
(ROOT/'resultados.json').write_text(json.dumps(rows,ensure_ascii=False,indent=2))
for name,data in [('todos_municipios.csv',rows),('municipios_douglas_lula.csv',focus),('municipios_lula.csv',lula),('regioes_ibge.csv',regional)]:
 with (ROOT/name).open('w',encoding='utf-8-sig',newline='') as f:
  w=csv.DictWriter(f,fieldnames=data[0].keys(),delimiter=';');w.writeheader();w.writerows(data)
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':11,'axes.spines.top':False,'axes.spines.right':False,'figure.facecolor':'white','axes.facecolor':'white'})
figures=[]
def save(fig,name):
 fig.savefig(ROOT/(name+'.png'),dpi=180,bbox_inches='tight');fig.savefig(ROOT/(name+'.svg'),bbox_inches='tight');figures.append(fig)
geo=json.loads((ROOT/'fontes/ibge_malha.json').read_text())
assert len(geo['features'])==92 and {f['properties']['codarea'] for f in geo['features']}==set(byid)
fig,ax=plt.subplots(figsize=(11.5,7))
for feat in geo['features']:
 r=byid[feat['properties']['codarea']];g=feat['geometry'];polys=g['coordinates'] if g['type']=='MultiPolygon' else [g['coordinates']]
 for poly in polys:ax.add_patch(Polygon(poly[0],facecolor=colors[group(r)],edgecolor='white',linewidth=.7))
ax.autoscale_view();ax.set_aspect(1/math.cos(math.radians(22.5)));ax.set_axis_off();ax.set_title('RJ 2026 · quem liderou para governador e presidente',loc='left',fontweight='bold',pad=20)
ax.annotate('Pinheiral\nRuas + Lula',xy=(-44.00,-22.52),xytext=(-44.65,-21.65),arrowprops={'arrowstyle':'->','color':'#925319'},color='#925319',fontweight='bold',bbox={'boxstyle':'round,pad=.5','fc':'#fff7e6','ec':'#dd841c'})
fig.subplots_adjust(bottom=.22)
ax.legend(handles=[Patch(color=c,label=f'{g} · {matrix[g]} '+('município' if matrix[g]==1 else 'municípios')) for g,c in colors.items()],loc='upper center',bbox_to_anchor=(.5,-.04),ncol=2,frameon=False,fontsize=10)
fig.text(.13,.025,'1º turno · 100% das seções · fonte: TSE. Malha simplificada: IBGE. Liderança por votos nominais.',fontsize=9,color='#555')
save(fig,'mapa_municipios')
fig,ax=plt.subplots(figsize=(10.5,6.5))
for g,c in colors.items():
 rs=[r for r in rows if group(r)==g];ax.scatter([r['lula_pct']-r['flavio_pct'] for r in rs],[r['douglas_pct']-r['paes_pct'] for r in rs],s=75 if g=='Ruas + Lula' else 38,c=c,label=f'{g} ({len(rs)})',alpha=.9,edgecolors='white',linewidth=.5)
ax.axhline(0,color='#444',lw=.9);ax.axvline(0,color='#444',lw=.9)
ax.annotate('Pinheiral\nLula +1,00 p.p.\nRuas +8,07 p.p.',(pin['lula_pct']-pin['flavio_pct'],pin['douglas_pct']-pin['paes_pct']),xytext=(8,22),arrowprops={'arrowstyle':'->','color':'#925319'},fontsize=10,color='#925319')
ax.set_xlabel('Margem Lula − Flávio (pontos percentuais)');ax.set_ylabel('Margem Ruas − Paes (pontos percentuais)');ax.set_title('Cada ponto representa um dos 92 municípios',loc='left',fontweight='bold');ax.grid(alpha=.13);ax.legend(fontsize=9,loc='lower left')
fig.text(.13,.02,'Direita do zero: Lula lidera. Acima do zero: Ruas lidera. Percentuais oficiais divulgados pelo TSE.',fontsize=9,color='#555');save(fig,'cruzamento_margens')
fig,ax=plt.subplots(figsize=(10,5))
y=[3.4,2.5,1,.1];cands=[('Lula',6639,46.641843473,'#b64c65'),('Flávio Bolsonaro',6497,45.64423212,'#2563a6'),('Douglas Ruas',6458,50.221634653,'#dd841c'),('Eduardo Paes',5420,42.149467299,'#aaa6bd')]
for yi,(name,v,pc,c) in zip(y,cands):ax.barh(yi,pc,color=c,height=.55);ax.text(pc+.6,yi,f'{p(pc)}% · {n(v)} votos',va='center',fontsize=11)
ax.set_yticks(y,[x[0] for x in cands]);ax.set_xlim(0,72);ax.set_xticks([0,20,40,60],['0%','20%','40%','60%']);ax.set_title('Pinheiral · votação dos dois primeiros em cada cargo',loc='left',fontweight='bold',pad=20);ax.set_xlabel('Percentual na base de divulgação de cada cargo');ax.grid(axis='x',alpha=.15);ax.set_axisbelow(True)
fig.text(.13,.025,'As bases diferem: presidente 14.234; governador 12.859, incluindo 296 votos sub judice. Fonte: TSE.',fontsize=9,color='#555');save(fig,'pinheiral_votacao')
with PdfPages(ROOT/'graficos.pdf') as pdf:
 for fig in figures:pdf.savefig(fig,bbox_inches='tight')
for fig in figures:plt.close(fig)
# Auditoria da soma municipal contra a UF, incluindo cada candidato.
sources=json.loads((ROOT/'fontes/consolidado.json').read_text());audit=[];long=[]
def candidates(d):return [c for cargo in d['carg'] for a in cargo['agr'] for par in a['par'] for c in par['cand']]
for ele,name in [('6257','rj_presidente'),('6259','rj_governador')]:
 st=json.loads((ROOT/'fontes'/f'{name}.json').read_text());cnt=collections.Counter()
 for x in sources:
  if x['eleicao']!=ele:continue
  assert x['data']['f']=='o' and x['data']['t']=='1' and x['data']['tf']=='s' and float(x['data']['s']['pstn'])==100
  for c in candidates(x['data']):
   cnt[c['n']]+=int(c['vap']);long.append({'municipio':byid[x['municipio']['cdi']]['municipio'],'codigo_tse':x['municipio']['cd'],'cargo':'Presidente' if ele=='6257' else 'Governador','numero':c['n'],'candidato':c['nmu'],'votos':int(c['vap']),'percentual_divulgado':float(c['pvapn'].replace(',','.')),'destinacao':c['dvt'],'situacao':c['st'],'fonte':x['url']})
 for c in candidates(st):
  audit.append({'cargo':name,'candidato':c['nmu'],'soma_municipios':cnt[c['n']],'total_uf':int(c['vap']),'diferenca':cnt[c['n']]-int(c['vap'])});assert audit[-1]['diferenca']==0
(ROOT/'auditoria.json').write_text(json.dumps(audit,ensure_ascii=False,indent=2))
with (ROOT/'todos_candidatos.csv').open('w',encoding='utf-8-sig',newline='') as f:
 w=csv.DictWriter(f,fieldnames=long[0].keys(),delimiter=';');w.writeheader();w.writerows(long)
methods=[
('Recorte','Primeiro turno de 2026, realizado em 04/10/2026; 92 municípios do RJ.'),
('Critério de liderança','Maior número de votos nominais entre todos os candidatos do cargo. Empates seriam identificados; não houve.'),
('Cruzar os cargos','Junção pelos códigos municipais TSE, conferidos com os códigos IBGE. Filtro: líder governador = Douglas Ruas E líder presidente = Lula.'),
('Cobertura','184 arquivos municipais, 2 arquivos estaduais, 100% das seções totalizadas e indicador de totalização final.'),
('Códigos oficiais','Eleição federal 6257, estadual 6259; cargos 0001 e 0003. Obtidos na configuração oficial, ambiente oficial.'),
('Percentual dos candidatos','Campo pvapn do TSE; votos em vap. Divisor da divulgação: vvc. Em governador, inclui votos anulado sub judice.'),
('Votos sub judice','Os percentuais reproduzem a divulgação consultada. Em Pinheiral: vvc 12.859 = vv 12.563 + vansj 296. Não há decisão judicial inferida.'),
('Brancos/nulos','Calculados sobre comparecimento, nunca sobre votos válidos. Anulado sub judice é registrado separadamente.'),
('Abstenção','Abstenções / eleitorado apto do cargo. As bases de eleitorado são conservadas separadamente por cargo.'),
('Regiões','Regiões geográficas imediatas e intermediárias da API oficial IBGE; não são as regiões administrativas do governo estadual.'),
('Médias regionais','Soma dos votos do candidato / soma das bases do cargo; não é a média simples dos percentuais municipais.'),
('Tempo da extração','Consulta em 07/10/2026 UTC. Totalização dos arquivos: governador 04/10/2026 22:19:52 e presidente 05/10/2026 12:51:05, horários como publicados pelo TSE.'),
('Verificação','Soma dos 92 municípios bate com o total estadual para cada um dos 21 candidatos; diferença zero.'),
('Limite da inferência','Coincidência territorial entre líderes não revela escolhas de um mesmo eleitor. Os totais não estimam transferência individual de votos.'),
('Escala','Este relatório mede municípios; não calcula votação por seção ou bairro. A zona 0030 consta para Pinheiral na configuração municipal.'),
('Pesquisa contextual','Exemplo Datafolha publicado em 02/10/2026; âmbito estadual. Não é uma pesquisa municipal de Pinheiral.'),
('Reprodução','Executar coletar.py, analisar.py e gerar_relatorio.py com as dependências de requirements.txt. Fontes baixadas ficam na pasta fontes; consolidado.json registra URLs e SHA-256.')]
# Excel com tabelas numéricas, fontes e glossário.
wb=Workbook();wb.remove(wb.active)
for title,data in [('92 municípios',rows),('Ruas e Lula',focus),('Lula liderou',lula),('Regiões IBGE',regional),('Todos os candidatos',long),('Auditoria',audit)]:
 ws=wb.create_sheet(title);headers=list(data[0]);ws.append(headers)
 for r in data:ws.append([r[k] for k in headers])
 ws.freeze_panes='B2';ws.auto_filter.ref=ws.dimensions
 for i,h in enumerate(headers,1):
  letter=get_column_letter(i);ws.column_dimensions[letter].width=48 if h.endswith('_url') or h=='fonte' else 30 if 'municipio' in h or 'regiao' in h else 23
  ws.cell(1,i).font=Font(color='FFFFFF',bold=True);ws.cell(1,i).fill=PatternFill('solid',fgColor='17324D')
  if 'pct' in h or '_pp' in h or 'percentual' in h:
   for j in range(2,ws.max_row+1):ws.cell(j,i).number_format='0.00'
  if h.endswith('_url') or h=='fonte':
   for j in range(2,ws.max_row+1):ws.cell(j,i).hyperlink=ws.cell(j,i).value;ws.cell(j,i).style='Hyperlink'
  if h.startswith('codigo_') or h=='numero':
   for j in range(2,ws.max_row+1):ws.cell(j,i).number_format='@'
 ws.sheet_view.showGridLines=False
ws=wb.create_sheet('Método e glossário');ws.append(['Item','Definição']);
for k,v in methods:ws.append([k,v])
for k,v in [('vap','Quantidade de votos nominais do candidato.'),('pvapn','Percentual de votos do candidato com precisão completa, convertido de vírgula decimal.'),('vvc','Base de votos válidos concorrentes usada na divulgação. Inclui válidos + anulado sub judice.'),('vv','Votos com destinação válida no arquivo; é diferente de vvc quando existem votos sub judice.'),('vansj','Votos anulados sub judice, preservados separadamente.'),('margens','Maior votação menos segunda maior; o cruzamento gráfico usa Lula-Flávio e Ruas-Paes.'),('tf / f / t','Totalização final / ambiente oficial / turno.'),('Percentuais na planilha','Números de 0 a 100; 50,22 significa 50,22%. Não usar formato percentual de Excel sem dividir por 100.')]:ws.append([k,v])
ws.column_dimensions['A'].width=32;ws.column_dimensions['B'].width=115;ws.freeze_panes='A2'
for row in ws:
 for c in row:c.alignment=Alignment(wrap_text=True,vertical='top')
wb.save(ROOT/'analise_rj_2026.xlsx')
# Texto completo.
def table(headers,data):return '| '+' | '.join(headers)+' |\n| '+' | '.join(['---']*len(headers))+' |\n'+'\n'.join('| '+' | '.join(map(str,r))+' |' for r in data)
def link(label,url):return f'[{label}]({url})'
src_g=link('TSE: governador em Pinheiral',pin['governador_url']);src_p=link('TSE: presidente em Pinheiral',pin['presidente_url'])
report=f'''# RJ 2026: municípios em que Douglas Ruas e Lula lideraram

Análise do primeiro turno de 04/10/2026. Consulta aos arquivos oficiais em 07/10/2026. Cobertura: 92 municípios, 184 arquivos municipais, 100% das seções totalizadas.

**Pinheiral é o único município do Rio de Janeiro em que Douglas Ruas foi o mais votado para governador e Lula foi o mais votado para presidente.** O resultado foi calculado a partir dos arquivos oficiais municipais do TSE, cruzados pelo código do município. “Venceu no município” significa liderança local; os cargos são decididos pelo total estadual ou nacional.

## 1. Como a análise foi feita

1. Consultei a configuração oficial do TSE para obter os códigos das eleições de 2026, o primeiro turno e os cargos corretos. Usei o ambiente oficial.
2. Obtive a lista oficial de municípios do RJ e seus códigos TSE/IBGE. São 92 municípios.
3. Baixei dois arquivos por município: governador e presidente, totalizando 184. Preservei as respostas originais, URLs e hashes SHA-256.
4. Verifiquei o ambiente, o turno, a totalização final e 100% das seções em cada arquivo.
5. Ordenei todos os candidatos de cada cargo pelo número de votos. Registrei líder, segundo colocado, margem em votos e margem em pontos percentuais. Não houve empate para a liderança.
6. Cruzei as duas listas pelo código municipal e apliquei o filtro conjunto: Douglas Ruas em primeiro para governador e Lula em primeiro para presidente.
7. Somei os 92 municípios para cada candidato e confrontei com o arquivo estadual do mesmo cargo. Os 21 totais de candidatos coincidem exatamente.
8. Calculei participação, votos em branco, nulos e sub judice, preservando os denominadores de cada cargo.
9. Acrescentei as regiões imediatas/intermediárias e a malha municipal do IBGE. As médias regionais são ponderadas pelos votos.
10. Contextualizei o resultado com uma pesquisa estadual do Datafolha e com os outros municípios em que Lula liderou. Essa pesquisa não mede Pinheiral individualmente.

## 2. O cruzamento dos 92 municípios

{table(['Líder para governador','Líder para presidente','Municípios','Parcela dos 92'],[['Douglas Ruas','Flávio Bolsonaro',78,'84,78%'],['Eduardo Paes','Lula',8,'8,70%'],['Eduardo Paes','Flávio Bolsonaro',5,'5,43%'],['Douglas Ruas','Lula',1,'1,09%']])}

Ruas liderou em 79 municípios; Paes, em 13. Lula liderou em nove; Flávio, em 83. Entre as nove cidades em que Lula ficou em primeiro, oito também colocaram Paes em primeiro para governador e uma colocou Ruas. A combinação Ruas–Lula aparece em 11,11% das cidades lideradas por Lula e em 1,27% das lideradas por Ruas.

![Mapa dos líderes municipais](mapa_municipios.png)

O número de municípios não representa o peso eleitoral: cada cidade conta uma vez nessa tabela, embora seus eleitorados tenham tamanhos diferentes. Pinheiral forneceu 0,15% dos votos estaduais de Ruas e 0,18% dos votos estaduais de Lula. Portanto, a coincidência identificada é um caso local de pequeno peso na soma estadual.

## 3. Pinheiral: os resultados completos

Pinheiral tem código TSE 58246 e código IBGE 3303955. Pertence à região geográfica imediata e intermediária de Volta Redonda – Barra Mansa, segundo a API do IBGE. A configuração municipal do TSE lista a zona eleitoral 0030. O recorte calculado aqui é municipal.

{table(['Cargo','Candidato','Votos','Percentual divulgado','Vantagem sobre o segundo'],[['Governador','Douglas Ruas','6.458','50,22%','1.038 votos / 8,07 p.p.'],['Governador','Eduardo Paes','5.420','42,15%','—'],['Presidente','Lula','6.639','46,64%','142 votos / 1,00 p.p.'],['Presidente','Flávio Bolsonaro','6.497','45,64%','—']])}

Fontes diretas: {src_g}; {src_p}.

![Votação em Pinheiral](pinheiral_votacao.png)

**As duas lideranças têm intensidades diferentes.** Lula ficou em primeiro por menos de um ponto percentual antes do arredondamento: 0,9976 p.p. Ruas teve uma vantagem de 8,0722 p.p. Lula teve a maior votação presidencial, com menos de 50% da base do cargo; Ruas ultrapassou 50% da base divulgada para governador no município.

Os demais candidatos a governador receberam: William Siri, 400 votos (3,11%); Garotinho, 296 (2,30%, anulado sub judice); Coronel Busnello, 167 (1,30%); Juliete, 62 (0,48%); André Marinho, 42 (0,33%); Luan Monteiro, 8 (0,06%); Cyro Garcia, 6 (0,05%).

Para presidente, os demais receberam: Augusto Cury, 429 (3,01%); Renan Santos, 330 (2,32%); Ronaldo Caiado, 277 (1,95%); Zema, 26 (0,18%); Samara, 15 (0,11%); Clariana Barão, 10 (0,07%); Hertz Dias, 3 (0,02%); Edmilson Costa, 3 (0,02%); Veterinário Wilson Grassi, 3 (0,02%); Rui Costa Pimenta, 2 (0,01%).

## 4. Participação e os denominadores dos percentuais

{table(['Indicador','Governador','Presidente'],[['Eleitorado apto','18.820','18.820'],['Comparecimento','14.774 (78,50%)','14.774 (78,50%)'],['Abstenções','4.046 (21,50%)','4.046 (21,50%)'],['Votos em branco','929 (6,29% do comparecimento)','251 (1,70% do comparecimento)'],['Votos nulos','986 (6,67% do comparecimento)','289 (1,96% do comparecimento)'],['Base do percentual divulgado','12.859','14.234'],['Votos com destinação válida (vv)','12.563','14.234'],['Anulado sub judice','296','0']])}

Brancos e nulos somaram 1.915 votos para governador (12,96% do comparecimento) e 540 para presidente (3,66%). A diferença é de 1.375 votos, ou 9,31 pontos percentuais sobre o mesmo comparecimento. Isso explica por que a base dos candidatos a governador é menor que a dos presidenciáveis, sem identificar as escolhas das pessoas que deixaram de dar voto nominal válido em um dos cargos.

A abstenção de Pinheiral, 21,50%, ficou abaixo dos 23,33% registrados no arquivo estadual de governador: diferença aproximada de 1,84 p.p., calculada antes do arredondamento. Ausências, brancos e nulos não têm preferência partidária identificável nesses dados.

O percentual de Ruas na divulgação é `6.458 / 12.859 × 100 = 50,22%`. O de Lula é `6.639 / 14.234 × 100 = 46,64%`. Se a base fosse todo o comparecimento, seriam 43,71% para Ruas e 44,94% para Lula. Sobre o eleitorado apto, seriam 34,31% e 35,28%, respectivamente.

**Nota sobre sub judice:** o arquivo de governador possui 296 votos de Garotinho com destinação “Anulado sub judice”. O TSE os preserva na base concorrente de divulgação, de 12.859, enquanto o campo `vv` registra 12.563 votos com destinação válida. Este relatório reproduz os percentuais oficiais consultados. Dividir apenas por `vv` daria 51,40% para Ruas, mas seria uma base diferente da divulgação. Esse cálculo alternativo não constitui decisão sobre o resultado estadual nem antecipa efeitos judiciais.

## 5. O que a coincidência territorial permite concluir

Pinheiral apresentou lideranças de partidos diferentes entre os dois cargos. Isso é evidência de um resultado municipal dividido. A apuração pública oferece os totais de cada candidatura; não oferece uma tabela que ligue o voto de presidente ao voto de governador de uma mesma pessoa.

Lula recebeu 1.219 votos a mais que Paes. Essa diferença não identifica 1.219 votos de Lula para Ruas: esses eleitores podem ter escolhido outros candidatos, branco ou nulo, e Paes também pode ter recebido votos de eleitores de outros presidenciáveis.

Ruas recebeu 39 votos a menos que Flávio, embora seu percentual divulgado seja 4,58 p.p. maior. A diferença entre os divisores dos cargos produz esse contraste. Comparar percentuais isoladamente pode sugerir uma expansão individual de apoio que os votos nominais não demonstram.

Os totais também não obrigam a existência de votos individuais Ruas–Lula. Considerando as duas escolhas no universo comum de 14.774 comparecentes informado para Pinheiral, o limite matemático mínimo de interseção é `máximo(0; 6.458 + 6.639 − 14.774) = 0`. O limite máximo é 6.458. Esse intervalo representa compatibilidade aritmética; não é uma estimativa de quantas pessoas votaram na combinação.

![Margens nos 92 municípios](cruzamento_margens.png)

## 6. Todas as cidades em que Lula liderou

{table(['Município','Lula','Flávio','Ruas','Paes','Líder governador'],[[r['municipio'],p(r['lula_pct'])+'%',p(r['flavio_pct'])+'%',p(r['douglas_pct'])+'%',p(r['paes_pct'])+'%','Ruas' if r['douglas_lula'] else 'Paes'] for r in lula])}

Pinheiral é a única linha dessa tabela que atende ao filtro conjunto. Conceição de Macabu teve lideranças especialmente apertadas: Lula por {n(next(r for r in lula if r['municipio']=='Conceição de Macabu')['margem_presidente_votos'])} votos e Paes por {n(next(r for r in lula if r['municipio']=='Conceição de Macabu')['margem_governador_votos'])} votos. A liderança de Paes ali impede sua inclusão no grupo Ruas–Lula.

O apoio institucional a um candidato não substitui a apuração. Por exemplo, Maricá não atende ao filtro: Ruas teve 49,69% e Paes 41,06%; Flávio teve 49,82% e Lula 43,18%. A inclusão se baseia no primeiro colocado dos dois cargos.

## 7. Pinheiral no contexto regional

{table(['Município da região imediata','Ruas','Paes','Lula','Flávio'],[[r['municipio'],p(r['douglas_pct'])+'%',p(r['paes_pct'])+'%',p(r['lula_pct'])+'%',p(r['flavio_pct'])+'%'] for r in rows if r['regiao_imediata']==pin['regiao_imediata']])}

Na região imediata de Volta Redonda – Barra Mansa, Ruas liderou em sete das oito cidades; Paes liderou em Rio Claro. Lula liderou apenas em Pinheiral. Portanto, a liderança estadual de Ruas no município acompanha a predominância regional, enquanto a liderança presidencial de Lula distingue Pinheiral de seus pares nessa região.

Para ampliar o contexto, estas são as cinco regiões geográficas intermediárias do IBGE. Elas não correspondem às regiões administrativas do governo estadual. Os percentuais abaixo usam os votos somados de cada região.

{table(['Região intermediária IBGE','Cidades','Ruas lidera','Paes lidera','Lula lidera','Ruas + Lula','Ruas %','Paes %','Lula %'],[[r['regiao'],r['municipios'],r['ruas_lidera'],r['paes_lidera'],r['lula_lidera'],r['ruas_lula'],p(r['douglas_pct']),p(r['paes_pct']),p(r['lula_pct'])] for r in regional])}

## 8. Contexto das pesquisas anteriores à votação

Usei como referência documental o Datafolha publicado em 02/10/2026, com campo de 29/09 a 01/10, 1.204 entrevistas presenciais em 35 municípios, margem de três pontos e confiança de 95%; registro RJ-02070/2026. No cenário com Garotinho, os votos válidos indicavam Paes com 47% e Ruas com 35%.

{table(['Candidato','Datafolha: cenário com Garotinho','TSE estadual: divulgação consultada','Diferença resultado − pesquisa'],[['Eduardo Paes','47,00%','42,76%','−4,24 p.p.'],['Douglas Ruas','35,00%','49,27%','+14,27 p.p.']])}

A liderança prevista nessa rodada se inverteu no resultado estadual. A comparação é descritiva: uma pesquisa estima intenção em uma data, enquanto a apuração contabiliza escolhas efetivas. Essa rodada não fornece uma estimativa representativa de Pinheiral e não explica, sozinha, as motivações locais. Não foi calculada uma média de institutos nem uma probabilidade de vitória futura.

Fonte: [relatório e metodologia do Datafolha](https://datafolha.folha.uol.com.br/eleicoes/2026/10/eduardo-paes-psd-mantem-a-lideranca-com-47-dos-votos-validos-douglas-ruas-pl-cresce-e-alcanca-35.shtml).

## 9. Precisão, cobertura e limites

A conclusão territorial se sustenta em todos os 92 municípios, e não em uma seleção de cidades. A soma municipal foi conferida para os 12 presidenciáveis e nove candidatos a governador: diferença zero em relação aos totais da UF. Os arquivos indicam totalização final e 100% das seções.

Não há margem de erro amostral na contagem apurada: a margem municipal é a diferença observada entre votos. Eventuais retotalizações podem alterar números ou bases; a fotografia preservada é a consulta de 07/10/2026. O estudo não estabelece causas, não infere intenção individual e não calcula resultados do segundo turno a partir do primeiro.

Este recorte usa o primeiro turno de 2026 para ambos os cargos. Comparar Ruas em 2026 com Lula no segundo turno de 2022 seria outro cruzamento, com outra lista de municípios.

## 10. Fontes, arquivos e reprodução

- [Configuração das eleições — TSE](https://resultados.tse.jus.br/oficial/comum/config/ele-c.json).
- [Municípios e códigos — TSE](https://resultados.tse.jus.br/oficial/ele2026/6257/config/mun-e006257-cm.json).
- [Governador: total estadual — TSE](https://resultados.tse.jus.br/oficial/ele2026/6259/dados/rj/rj-c0003-e006259-u.json).
- [Presidente: total no RJ — TSE](https://resultados.tse.jus.br/oficial/ele2026/6257/dados/rj/rj-c0001-e006257-u.json).
- {src_g}.
- {src_p}.
- [Documentação dos resultados unificados — TSE](https://www.tse.jus.br/eleicoes/eleicoes-2026-content/arquivos/divulgacao-de-resultados/tse-ea20-arquivo-de-resultado-unificado).
- [Dados abertos 2026 — TSE](https://dadosabertos.tse.jus.br/dataset/resultados-2026). O catálogo consultado disponibilizava relatórios de totalização; a coleta municipal utilizou os JSONs oficiais de divulgação.
- [Localidades e regiões — IBGE](https://servicodados.ibge.gov.br/api/v1/localidades/estados/33/municipios).
- [Malha municipal simplificada — IBGE](https://servicodados.ibge.gov.br/api/v3/malhas/estados/33?formato=application/vnd.geo+json&qualidade=minima&intrarregiao=municipio).

A planilha `analise_rj_2026.xlsx` inclui 92 municípios, o filtro Ruas–Lula, as nove cidades de Lula, regiões, todos os candidatos, auditoria e método/glossário. Os CSVs usam ponto e vírgula e UTF-8 com BOM; percentuais são números de 0 a 100. A pasta `fontes` preserva os dados consultados e as URLs por município. Os gráficos também estão em SVG, PNG e PDF.
'''
(ROOT/'relatorio.md').write_text(report)
# Relatório HTML independente: imagens incorporadas, filtros e tabela municipal pesquisável.
body=markdown.markdown(report,extensions=['tables','fenced_code'])
for name in ['mapa_municipios','cruzamento_margens','pinheiral_votacao']:
 body=body.replace(f'src="{name}.png"',f'src="data:image/png;base64,{base64.b64encode((ROOT/(name+".png")).read_bytes()).decode()}"')
interactive='''<section id="explorar"><h2>Explore os 92 municípios</h2><p>Filtre pelo município ou pela combinação de líderes. As colunas preservam a base percentual de cada cargo.</p><div class="controls"><label>Município ou região <input id="busca" type="search" placeholder="Digite um nome"></label><label>Combinação de líderes <select id="grupo"><option value="">Todos os municípios</option><option>Ruas + Lula</option><option>Paes + Lula</option><option>Ruas + Flávio</option><option>Paes + Flávio</option></select></label><label>Ordenar <select id="ordem"><option value="municipio">Município</option><option value="lula_pct">Lula: maior percentual</option><option value="douglas_pct">Ruas: maior percentual</option><option value="governador_eleitorado">Maior eleitorado</option></select></label></div><p id="contagem" role="status"></p><div class="tablewrap"><table><thead><tr><th>Município</th><th>Combinação</th><th>Ruas %</th><th>Paes %</th><th>Lula %</th><th>Flávio %</th><th>Abstenção %</th><th>Fonte</th></tr></thead><tbody id="dados"></tbody></table></div></section>'''
css='''body{margin:0;background:#f4f6f8;color:#203044;font:17px/1.65 system-ui,sans-serif}main{max-width:1060px;margin:40px auto;padding:45px;background:white;border-radius:12px}h1{font-size:2.3rem;line-height:1.2;color:#17324d}h2{font-size:1.45rem;margin-top:2.8rem}a{color:#155da3}p,li{max-width:100ch}img{display:block;width:100%;height:auto;margin:25px 0}table{border-collapse:collapse;font-size:14px;min-width:540px;width:100%;margin:20px 0}th{background:#17324d;color:white;text-align:left}td,th{padding:10px;border-bottom:1px solid #dce3e9}tr:nth-child(even){background:#f5f7fa}code{background:#f1f3f5;padding:2px 5px}.tablewrap{overflow-x:auto}.controls{display:flex;flex-wrap:wrap;gap:18px}.controls label{display:flex;flex-direction:column;font-size:14px}input,select,button{font:inherit;padding:10px;border:1px solid #b8c5d1;border-radius:5px;background:white}.topbar{display:flex;align-items:center;gap:20px;padding-bottom:15px;border-bottom:1px solid #dce3e9;font-size:14px}button{cursor:pointer}.focus{background:#fff2d9!important}#contagem{font-size:14px}@media(max-width:700px){main{margin:0;padding:22px;border-radius:0}h1{font-size:1.8rem}}@media print{body{background:white}main{margin:0;padding:0;max-width:none}.topbar button,.controls,#explorar{display:none}a{color:inherit;text-decoration:none}img{break-inside:avoid}h2{break-after:avoid}table{font-size:10px}tr{break-inside:avoid}}'''
js='''const rows=__DATA__;const nf=new Intl.NumberFormat('pt-BR',{minimumFractionDigits:2,maximumFractionDigits:2});const norm=s=>s.normalize('NFD').replace(/[\\u0300-\\u036f]/g,'').toLowerCase();const esc=s=>String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));function group(r){return(r.lider_governador==='DOUGLAS RUAS'?'Ruas':'Paes')+' + '+(r.lider_presidente==='LULA'?'Lula':'Flávio')}function render(){const q=norm(document.getElementById('busca').value),g=document.getElementById('grupo').value,o=document.getElementById('ordem').value;let rs=rows.filter(r=>(!q||norm(r.municipio+' '+r.regiao_imediata).includes(q))&&(!g||group(r)===g));rs.sort((a,b)=>o==='municipio'?a.municipio.localeCompare(b.municipio,'pt-BR'):b[o]-a[o]);document.getElementById('contagem').textContent=rs.length+' municípios exibidos';document.getElementById('dados').innerHTML=rs.map(r=>'<tr class="'+(r.douglas_lula?'focus':'')+'"><td>'+esc(r.municipio)+'</td><td>'+group(r)+'</td>'+['douglas_pct','paes_pct','lula_pct','flavio_pct','governador_abstencao_pct'].map(k=>'<td>'+nf.format(r[k])+'</td>').join('')+'<td><a href="'+esc(r.governador_url)+'">Gov.</a> · <a href="'+esc(r.presidente_url)+'">Pres.</a></td></tr>').join('')}['busca','grupo','ordem'].forEach(id=>document.getElementById(id).addEventListener('input',render));render();document.querySelectorAll('main>table').forEach(t=>{const div=document.createElement('div');div.className='tablewrap';t.parentNode.insertBefore(div,t);div.appendChild(t)});'''.replace('__DATA__',json.dumps(rows,ensure_ascii=False).replace('</','<\\/'))
page='<!doctype html><html lang="pt-BR"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>RJ 2026 · Douglas Ruas e Lula</title><style>'+css+'</style></head><body><main><div class="topbar"><span>Consulta: 07/10/2026 · primeiro turno · fontes TSE e IBGE</span><button onclick="window.print()">Imprimir / salvar PDF</button><a href="#explorar">Explorar municípios</a></div>'+body+interactive+'</main><script>'+js+'</script></body></html>'
(ROOT/'relatorio.html').write_text(page)
(ROOT/'requirements.txt').write_text('requests==2.34.2\nmatplotlib==3.11.2\nopenpyxl==3.1.5\nmarkdown==3.11\n')
# Pacote compartilhável com relatório independente e dados, sem dependências locais.
with zipfile.ZipFile(ROOT/'analise_rj_2026.zip','w',zipfile.ZIP_DEFLATED) as z:
 for name in ['relatorio.html','relatorio.md','analise_rj_2026.xlsx','todos_municipios.csv','municipios_douglas_lula.csv','municipios_lula.csv','regioes_ibge.csv','todos_candidatos.csv','auditoria.json','mapa_municipios.png','mapa_municipios.svg','cruzamento_margens.png','cruzamento_margens.svg','pinheiral_votacao.png','pinheiral_votacao.svg','graficos.pdf','coletar.py','analisar.py','gerar_relatorio.py','requirements.txt']:
  z.write(ROOT/name,name)
 for path in (ROOT/'fontes').rglob('*'):
  if path.is_file() and path.suffix in ['.json','.pdf','.zip']:z.write(path,path.relative_to(ROOT))
# Verificações dos produtos finais.
check=load_workbook(ROOT/'analise_rj_2026.xlsx',read_only=True,data_only=True)
assert check['92 municípios'].max_row==93 and check['Ruas e Lula'].max_row==2 and check['Lula liderou'].max_row==10
assert len(long)==92*21 and len(audit)==21 and all(a['diferenca']==0 for a in audit)
assert sum(matrix.values())==92 and sum(x['municipios'] for x in regional)==92
assert 'src="mapa_' not in page and 'Pinheiral' in page and '<title>' in page
for name in ['relatorio.html','analise_rj_2026.xlsx','analise_rj_2026.zip','relatorio.md']:print(name,(ROOT/name).stat().st_size,'bytes')
print('Validação: 92 municípios, 1 Ruas+Lula, 9 Lula; 1.932 linhas de candidatos e 21 totais estaduais iguais.')
