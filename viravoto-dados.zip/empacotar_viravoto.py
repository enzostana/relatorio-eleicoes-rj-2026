from pathlib import Path
import json, csv, zipfile, hashlib
from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment
ROOT=Path(__file__).resolve().parent
SITE=ROOT
assets=SITE/'assets'
def read(n): return json.loads((assets/(n+'.json')).read_text())
manifest=json.loads((SITE/'fontes-viravoto.json').read_text())
method=(SITE/'metodo-viravoto.md').read_text()
wb=Workbook();wb.remove(wb.active)
def sheet(name,rows):
 ws=wb.create_sheet(name)
 if not rows: return
 keys=list(dict.fromkeys(k for r in rows for k in r))
 ws.append(keys)
 for r in rows:
  ws.append([json.dumps(r[k],ensure_ascii=False) if isinstance(r.get(k),(dict,list)) else r.get(k) for k in keys])
 ws.freeze_panes='A2';ws.auto_filter.ref=ws.dimensions
 for c in ws[1]:c.font=Font(color='FFFFFF',bold=True);c.fill=PatternFill('solid',fgColor='013F88');c.alignment=Alignment(wrap_text=True)
 for col in ws.columns:
  ws.column_dimensions[col[0].column_letter].width=min(60,max(16,max(len(str(c.value or '')) for c in col[:80])+2))
 for row in ws.iter_rows(min_row=2):
  for c in row:c.alignment=Alignment(vertical='top',wrap_text=True)
sheet('Municípios',read('data'));sheet('Auditoria',read('estudo')['auditoria']);sheet('Governo pesquisas',read('pesquisas'));sheet('Presidente pesquisa RJ',read('pesquisas-presidencia'));sheet('Participação histórica',read('estudo')['historico']);sheet('Propostas',read('contexto')['propostas']);sheet('Limitações',read('contexto')['lacunas'])
for file,name in [('prioridades-estaduais.csv','Prioridades março'),('conhecimento-candidatos.csv','Conhecimento março')]:
 with (SITE/file).open(encoding='utf-8-sig',newline='') as f:sheet(name,list(csv.DictReader(f,delimiter=';')))
sheet('Método',[{'seção':'Escopo','texto':method}]);sheet('Fontes',[{'tipo':'Pesquisa governo','url':p['fonte'],'campo_fim':p['campo_fim']} for p in read('pesquisas')]+[{'tipo':'Prioridades e conhecimento','url':read('contexto')['prioridades']['fonte'],'campo_fim':'2026-03-10'}]+[{'tipo':'Programa espelho','url':p['espelho'],'sha256':p['sha256']} for p in read('contexto')['programas'].values()]);wb.save(SITE/'viravoto-dados.xlsx')
