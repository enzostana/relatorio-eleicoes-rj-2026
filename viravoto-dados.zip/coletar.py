from pathlib import Path
import requests,json,concurrent.futures,time,hashlib
ROOT=Path(__file__).parent
BASE='https://resultados.tse.jus.br/oficial/ele2026/'
(ROOT/'fontes').mkdir(exist_ok=True)
bootstrap={
 'config':'https://resultados.tse.jus.br/oficial/comum/config/ele-c.json',
 'municipios':BASE+'6257/config/mun-e006257-cm.json',
 'rj_presidente':BASE+'6257/dados/rj/rj-c0001-e006257-u.json',
 'rj_governador':BASE+'6259/dados/rj/rj-c0003-e006259-u.json',
 'ibge_municipios':'https://servicodados.ibge.gov.br/api/v1/localidades/estados/33/municipios',
 'ibge_malha':'https://servicodados.ibge.gov.br/api/v3/malhas/estados/33?formato=application/vnd.geo+json&qualidade=minima&intrarregiao=municipio'
}
def initial(kv):
 name,url=kv;path=ROOT/'fontes'/(name+'.json')
 if not path.exists():
  r=requests.get(url,timeout=30);r.raise_for_status();path.write_text(json.dumps(r.json(),ensure_ascii=False))
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:list(pool.map(initial,bootstrap.items()))
config=json.loads((ROOT/'fontes/config.json').read_text())
pleito=next(x for x in config['pl'] if x['c']=='ele2026' and x['dt']=='04/10/2026')
assert {'6257','6259'} <= {e['cd'] for e in pleito['e'] if e['t']=='1'}
mun=next(x['mu'] for x in json.loads((ROOT/'fontes/municipios.json').read_text())['abr'] if x['cd']=='rj')
assert len(mun)==92
jobs=[(m,e,c) for m in mun for e,c in [('6257','0001'),('6259','0003')]]
(ROOT/'fontes/municipais').mkdir(exist_ok=True)
def get(job):
 m,e,c=job;name=f"rj{m['cd']}-c{c}-e{int(e):06d}-u.json";url=f'{BASE}{e}/dados/rj/{name}';p=ROOT/'fontes/municipais'/name
 if p.exists():data=json.loads(p.read_text())
 else:
  for attempt in range(3):
   try:
    r=requests.get(url,timeout=30);r.raise_for_status();data=r.json();p.write_text(json.dumps(data,ensure_ascii=False));break
   except Exception:
    if attempt==2:raise
    time.sleep(attempt+1)
 return {'municipio':m,'eleicao':e,'url':url,'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'data':data}
with concurrent.futures.ThreadPoolExecutor(max_workers=6) as pool:
 out=list(pool.map(get,jobs))
(ROOT/'fontes/consolidado.json').write_text(json.dumps(out,ensure_ascii=False,indent=2))
print('Arquivos municipais:',len(out))
for x in out[:2]:
 d=x['data'];print(x['municipio']['nm'],d.keys());print('participação',d['e']);print('votos',d['v'])
