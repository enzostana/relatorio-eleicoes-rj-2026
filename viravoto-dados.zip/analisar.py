from pathlib import Path
import json,csv,collections,math
ROOT=Path(__file__).parent
src=json.loads((ROOT/'fontes/consolidado.json').read_text())
def candidates(d):return [c for cargo in d['carg'] for agr in cargo['agr'] for p in agr['par'] for c in p['cand']]
def pct(c):return float(c['pvapn'].replace(',','.'))
by=collections.defaultdict(dict)
for x in src:by[x['municipio']['cd']][x['eleicao']]=x
rows=[]
for code,ele in by.items():
 p,g=ele['6257'],ele['6259'];pc=sorted(candidates(p['data']),key=lambda c:int(c['vap']),reverse=True);gc=sorted(candidates(g['data']),key=lambda c:int(c['vap']),reverse=True)
 pd={c['n']:c for c in pc};gd={c['n']:c for c in gc}
 row={'municipio':p['municipio']['nm'].title(),'codigo_tse':code,'codigo_ibge':p['municipio']['cdi'],'lider_governador':gc[0]['nmu'],'lider_presidente':pc[0]['nmu'],'douglas_lula':gc[0]['n']=='22' and pc[0]['n']=='13','margem_governador_votos':int(gc[0]['vap'])-int(gc[1]['vap']),'margem_governador_pp':pct(gc[0])-pct(gc[1]),'margem_presidente_votos':int(pc[0]['vap'])-int(pc[1]['vap']),'margem_presidente_pp':pct(pc[0])-pct(pc[1])}
 for name,dic,n in [('douglas',gd,'22'),('paes',gd,'55'),('garotinho',gd,'10'),('siri',gd,'50'),('lula',pd,'13'),('flavio',pd,'22')]:
  row[name+'_votos']=int(dic[n]['vap']);row[name+'_pct']=pct(dic[n])
 row['paes_menos_lula_pp']=row['paes_pct']-row['lula_pct'];row['douglas_menos_flavio_pp']=row['douglas_pct']-row['flavio_pct']
 for name,x in [('governador',g),('presidente',p)]:
  d=x['data'];row[name+'_apuracao_pct']=float(d['s']['pstn']);row[name+'_eleitorado']=int(d['e']['te']);row[name+'_comparecimento']=int(d['e']['c']);row[name+'_abstencoes']=int(d['e']['a']);row[name+'_abstencao_pct']=float(d['e']['pan'].replace(',','.'));row[name+'_brancos']=int(d['v']['vb']);row[name+'_nulos']=int(d['v']['tvn']);row[name+'_brancos_pct']=float(d['v']['pvbn'].replace(',','.'));row[name+'_nulos_pct']=float(d['v']['ptvnn'].replace(',','.'));row[name+'_validos']=int(d['v']['vv']);row[name+'_base_percentual']=int(d['v']['vvc']);row[name+'_subjudice']=int(d['v']['vansj']);row[name+'_url']=x['url'];row[name+'_data']=d['dt'];row[name+'_hora']=d['ht']
 rows.append(row)
rows.sort(key=lambda r:r['municipio']);focus=[r for r in rows if r['douglas_lula']]
for name,items in [('todos_municipios.csv',rows),('municipios_douglas_lula.csv',focus)]:
 with (ROOT/name).open('w',encoding='utf-8-sig',newline='') as f:
  w=csv.DictWriter(f,fieldnames=rows[0].keys(),delimiter=';');w.writeheader();w.writerows(items)
(ROOT/'resultados.json').write_text(json.dumps(rows,ensure_ascii=False,indent=2))
print('MATRIZ',dict(collections.Counter((r['lider_governador'],r['lider_presidente']) for r in rows)))
print('FOCO',len(focus))
for r in sorted(focus,key=lambda r:r['governador_comparecimento'],reverse=True):
 print(r['municipio'],{k:round(r[k],3) if isinstance(r[k],float) else r[k] for k in ['douglas_votos','douglas_pct','paes_votos','paes_pct','lula_votos','lula_pct','flavio_votos','flavio_pct','margem_governador_pp','margem_presidente_pp','governador_abstencao_pct','paes_menos_lula_pp']})
print('TOTAIS FOCO',{k:sum(r[k] for r in focus) for k in ['douglas_votos','paes_votos','lula_votos','flavio_votos','governador_eleitorado','governador_comparecimento','governador_base_percentual','presidente_base_percentual','governador_abstencoes','governador_brancos','governador_nulos']})
print('LULA LIDEROU',[r['municipio'] for r in rows if r['lider_presidente']=='LULA'])
print('AUDITORIA')
for ele,prefix,name in [('6257','presidente','rj_presidente'),('6259','governador','rj_governador')]:
 state=json.loads((ROOT/'fontes'/f'{name}.json').read_text());want={c['n']:int(c['vap']) for c in candidates(state)};got=collections.Counter()
 for x in src:
  if x['eleicao']==ele:
   assert x['data']['tf']=='s' and x['data']['t']=='1' and x['data']['f']=='o' and float(x['data']['s']['pstn'])==100
   for c in candidates(x['data']):got[c['n']]+=int(c['vap'])
 print(ele,dict(got)==want,'diferenças',{n:got[n]-v for n,v in want.items() if got[n]!=v})
 print('base',sum(r[prefix+'_base_percentual'] for r in rows),state['v']['vvc'])
print('STATE GOV V',json.loads((ROOT/'fontes/rj_governador.json').read_text())['v'])
